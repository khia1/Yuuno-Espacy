package com.example.yuuno;

public class Const {
    public static final String USERS = "users";
    public static final String POSTS = "posts";
}
