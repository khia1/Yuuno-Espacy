package com.example.yuuno;

import android.content.Context;
import android.os.Environment;

import androidx.recyclerview.widget.RecyclerView;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;
import androidx.test.uiautomator.UiDevice;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import net.kultprosvet.androidcourse.socialapp.models.Post;
import net.kultprosvet.androidcourse.socialapp.ui.MainActivity;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.platform.app.InstrumentationRegistry.getInstrumentation;
import static net.kultprosvet.androidcourse.socialapp.Const.POSTS;



@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    private static final String EMAIL = "blt@blt.blt";
    private static final String PASSWORD = "123456";
    private static final long SLEEP_TIME_MILLIS = 2000L;
    private static final int FIRST_POSITION = 1;
    private static UiDevice sUiDevice;
    private static Context sContext;
    private DatabaseReference mDbRef;
    private int mCounter = 1;

    @Rule
    public ActivityTestRule<MainActivity> rule = new ActivityTestRule<>(MainActivity.class);

    @BeforeClass
    public static void init(){
        sContext = getInstrumentation().getTargetContext();
        sUiDevice = UiDevice.getInstance(getInstrumentation());
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            FirebaseAuth.getInstance().signInWithEmailAndPassword(EMAIL, PASSWORD);
            try {
                Thread.sleep(SLEEP_TIME_MILLIS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void scrollToPositionTest() {
        int randomPos = getRandomRecyclerPosition(R.id.main_posts_list);
        onView(withId(R.id.main_posts_list)).perform(RecyclerViewActions.scrollToPosition(randomPos));
    }

    @Test
    public void clickAtPositionTest() {
        takeScreenshot("clickAtPositionTest start");
        int randomPos = getRandomRecyclerPosition(R.id.main_posts_list);
        onView(withId(R.id.main_posts_list))
                .perform(RecyclerViewActions.actionOnItemAtPosition(randomPos, click()));
        Espresso.pressBack();
        takeScreenshot("clickAtPositionTest finish");
    }

    private int getRandomRecyclerPosition(int recyclerId) {
        Random rand = new Random();
        //Get the actual drawn RecyclerView
        RecyclerView recyclerView = (RecyclerView) rule.getActivity().findViewById(recyclerId);
        //If the RecyclerView exists, get the item count from the adapter
        int n = (recyclerView == null) ? FIRST_POSITION : recyclerView.getAdapter().getItemCount();
        //Return a random number from 0 (inclusive) to adapter.itemCount() (exclusive)
        return rand.nextInt(n);
    }

    @Test
    public void getPosts() {
        mDbRef = FirebaseDatabase.getInstance().getReference();
        mDbRef.child(POSTS).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                dataSnapshot.getChildrenCount();
                List<Post> posts = new ArrayList<>();
                for (int i = 0; i < dataSnapshot.getChildrenCount(); i++) {
                    Post post = dataSnapshot.getValue(Post.class);
                    posts.add(post);

                    onView(withId(R.id.main_posts_list))
                            .perform(RecyclerViewActions.actionOnItemAtPosition(i, click()));

                    onView(withId(R.id.post_title)).check(matches(withText(post.getTitle())));
                    onView(withId(R.id.post_body)).check(matches(withText(post.getBody())));
                    onView(withId(R.id.post_author)).check(matches(withText(post.getAuthor())));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void takeScreenshot(String name) {
        File pic = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        if (!pic.exists()) {
            pic.mkdir();
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath() + "/Screenshots");
        if (!dir.exists()) {
            dir.mkdir();
        }
        File file = new File(dir.getAbsolutePath() + "/"+String.format("%02d", mCounter)+"_" + name + ".png");
        sUiDevice.takeScreenshot(file);
        mCounter++;
    }

    @Test
    public void logOutTest() {
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getTargetContext());
        onView(withText(sContext.getString(R.string.log_out))).perform(click());
    }
}
